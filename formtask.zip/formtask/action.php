<?php 

extract($_POST);

$servername = "localhost";
$username = "root";
$password = "";
$dbname="timingform";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO formdata (name, email, date_birth,yourself,captcha,created_date)
VALUES ('$name','$email','$date','$comment','$captcha',now())";

if ($conn->query($sql) === TRUE) {
  echo 1;
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

//print_r($conn);
?>