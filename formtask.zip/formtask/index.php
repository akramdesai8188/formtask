<!DOCTYPE html>
<html lang="en">
<head>
  <title>Timing form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Timing Form</h2>
     Time :  <span id='time'>3</span>
 
    <div class="form-group">
      <label for="email">Name:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter Name" name="name">
        <span id="nameError" style="color:red;font-size:14px"></span>
    </div>
    <div class="form-group">
      <label for="pwd">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter Email" name="email">
      <span id="emailError" style="color:red;font-size:14px"></span>
    </div>
    <div class="form-group">
      <label for="pwd">Date Of Birth:</label>
      <input type="date" class="form-control" id="date" placeholder="Enter password" name="date">
       <span id="dateError" style="color:red;font-size:14px"></span>
    </div>
     <div class="form-group">
      <label for="pwd">About Yoursrlf</label>
   <textarea class="form-control" rows="5" id="comment"></textarea>
    <span id="commentError" style="color:red;font-size:14px"></span>
        </div>
         <div class="form-group bg-dark text-white p-2 w-50" >
         <?php $rand=(rand(1,10000)); 
		 ?>
         <span style='font-size:40px'><?php echo $rand; ?></span>
         
         </div>
        <div class="form-group">
        
      <label for="captcha">Captcha:</label>
      <input type="text" class="form-control" id="captcha" placeholder="Please fill captcha value" name="captcha">
       <span id="captchaError" style="color:red;font-size:14px"></span>
      <input type="hidden" value="<?php echo $rand; ?>" class="form-control" id="captchaval" placeholder="Please fill captcha value" >
        
    </div>
    <button type="submit" class="btn btn-primary" onClick="submit()">Submit</button>

</div>
<script>
function submit()
{
	
name=$("#name").val();
	date=$("#date").val();
	email=$("#email").val();
	comment=$("#comment").val();
	captcha=$("#captcha").val();
	captchaval=$("#captchaval").val();
	
	
if(validation(name,date,email,comment,captcha,captchaval))
{
	var val = { name : name, date : date,email:email, comment: comment, captcha : captcha }
	 $.ajax({ 
		 type: "post",   
         url: "action.php",  
		 data:val,
         async: false,
         success : function(text)
         {
			 if(text==1)
			 {
             alert("Record submited successful");
			  window.location.reload(); 
			 }
			 else{
				  alert("Record submiting fail");
				 }
         }
    });
}
	
}
function validation(name,date,email,comment,captcha,captchaval)
{
	
	if(name=='')
	{
	$("#nameError").html('Please fill name');
	 $("#nameError").show();
	return false;	
    }
	else{
		 $("#nameError").hide();
		}
		if(email=='')
	{
	$("#emailError").html('Please fill email');
	 $("#emailError").show();
	return false;	
    }
	
		re =  /\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
  
		if(re.test(email))
		{		
			$("#emailError").hide();
     	
		}
		else{
			//alert('email');
			$("#emailError").html('Wrong email id');
			 $("#emailError").show();
			return false;
		// $("#emailError").hide();
		}
		
	if(date=='')
	{
		
	$("#dateError").html('Please fill date');	
	$("#dateError").show();
	return false;	
    }
	else{
		 $("#dateError").hide();
		}
	
	if(comment=='')
	{
	$("#commentError").html('Please fill comment');	
	$("#commentError").show();
	return false;	
    }
	else{
		 $("#commentError").hide();
		}
		
		//alert('captcha'+captcha+'captchaval'+captchaval);
		if(captcha=='')
	{
	$("#captchaError").html('Please fill captcha');	
	$("#captchaError").show();
	return false;	
    }
	else if(captcha!=captchaval)
	{
	$("#captchaError").html('Captcha is wrong');	
	$("#captchaError").show();
	return false;	
    }	
	else{
		 $("#captchaError").hide();
		}
	return true;
	
	
}



coundown();
var i=59;
var min=2;
function coundown(){
   setInterval(() => {
  if (this.i == 0) {
    return;
  }
 $("#time").html(min +':'+ i--);
 if(i==1 && min > 0)
 {
	 min--;
	 i=59;
 }
 else if (min==0)
 {
	clearInterval();
	min=1;
	alert('timeout'); 
	 window.location.reload(); 
  }

}, 1000);
}
</script>
</body>
</html>
